% NWC and Stepping stone source code with the corrective degeneracy problem was written by W.Boonphakdee
%During October 1-5,2015
 % Test example from F.S.Hillier and G.J. Lieberman. "Introduction to
% Operations Research" 8th edition, 2005
% If command window displays " Undefined function or variable 'jneg'" this
% code fails to solve this problem. 
clear
tic
c=[464 513 464 513
   352 416 690 352
   995 682 388 388];
[m,n]=size(c);
s=[75
    125
    100];
d=[80 65 70 85];
r=0.01;% Extra value for adding element in corrective degeneracy method
nvar = m+n-1;

x=zeros(m+1,n+1);

s1=zeros(m,1); 

d1=zeros(1,n); 

% Sum of demand and supply
  sumd=0;
sumd1=0;
  for j=1:n
      
      sumd=sumd+d(j);
      d1(j)=d(j);
      sumd1=sumd1+d1(j);
  end


sums=0;
sums1=0;
for i=1:m
    sums=sums+s(i);
    s1(i)=s(i);
    sums1=sums1+s1(i);
end
  % Balance supply and demand
  if sums~=sumd
      disp('Review amount of supply and demand');
      return
  end
            
         

     toc
     tic
% Construct the initial basic feasible solution for transportation problem with Northwest corner rule 
% Code of Northwest-corner rule has been  written in form of MATLAB source code by Warut Boonphakdee
%  on August 17,2015


for j=1:n
  while d1(j)>0
    for i=1:m
       
           if s1(i)>0 &&  d1(j)>0
               iall=i;
               jall=j;
               break
           end
    end

    if d1(jall)>s1(iall)
       d1(jall)=d1(jall)-s1(iall);
       x(iall,jall)=s1(iall);
       s1(iall)=0;
    elseif d1(jall)<s1(iall)
        s1(iall)=s1(iall)-d1(jall);
        x(iall,jall)=d1(jall);
        d1(jall)=0;
    elseif d1(jall)==s1(iall) 
         x(iall,jall)=d1(jall);
        d1(jall)=0;
        s1(iall)=0;
       
    end
  end
end
  
 disp('Occupied matrix of NWC');
 disp(x);
         

  % Calulate the objective function of the BF solution (NWC)
     ZNWC=0;
     for i=1:m
         for j=1:n
             if x(i,j)>0
                 ZNWC=ZNWC+x(i,j)*c(i,j);
             end
         end
     end
%% number of non-basic variables in astepstone
 countnwc=0;
 for i=1:m
   for j=1:n
        if x(i,j)>0
          countnwc=countnwc+1;
        end
   end
 end

   % Check degeneracy solution
reducetant=m+n-1;
if countnwc>=reducetant
   disp('Non-degeneracy problem');
   disp('Total cost ');
   disp(ZNWC);
   degen=0;
else
     disp('The degeneracy NWC');
    disp('Total cost');
    disp(ZNWC);
    degen=1;
    
    
end
if degen==1
 % How to correct degeneracy problem
   numdegen=reducetant-countnwc;
     iterationDegen=0;
 for A=1:numdegen
     iterationDegen=iterationDegen+1;
    % Count the number of the basic cell on each row and column
     
    
      for j=1:n
           countcol=0;
          for i=1:m
              if x(i,j)>0
              countcol=countcol+1;
              end
          end
         x(m+1,j)=countcol;
      end
      for i=1:m
            countrow=0;
          for j=1:n
              if x(i,j)>0
              countrow=countrow+1;
              end
          end
         x(i,n+1)=countrow;
      end
     
   
    % Assign adding one on the entering cell
       for j=1:n-1
           if x(m+1,j)==1
               jenter=j;
               for i=1:m-1
                   if x(i,n+1)==1
                       ienter=i;
                       break
                   end
               end
           end
       end
       if x(ienter,jenter)== 0 
          x(ienter,jenter)=r;
          break
       end
 end
 % Add demand and supply with r
      for j=1:n
          for i=1:m
              if x(i,j)==r
                  d(j)=d(j)+r;
              end
          end
      end
      for i=1:m
          for j=1:n
              if x(i,j)==r
                  s(i)=s(i)+r;
              end
          end
      end
 end               
 
     %% The degeneracy
     countxdegen=0;
   
      
     for i=1:m
         for j=1:n
             if x(i,j)>0
                 countxdegen=countxdegen+1;
                
             end
         end
     end
     
     
     if countxdegen>=reducetant;
        
     else
         disp('Do not correct Degeneracy VAM');
         
       
       %  return
        
     end
    
 
     % This steppingstone source code has been written by W. Boonphakdee.
     % on Oct 1-5,2015
     countstep=0;
 for A=1:m*n   
     countstep=countstep+1;
    %% Construct the non-basic (unused) cell matrix
     nonx=zeros(m,n);
     for j=1:n
         for i=1:m
             if x(i,j)==0
                nonx(i,j)=1;
             end
         end
     end
      % Starting the improvement index matrix
      costloop=zeros(m,n);
      for j=1:n
          for i=1:m
              if x(i,j)>0
                 costloop(i,j)=inf;
              end
          end
      end
  for k=1:(m*n)%-countxdegen
     
        % Assign an entering cell to x matrix
        countnon=0;
        for j=1:n
           
            for i=1:m
                if nonx(i,j)==1
                    ibas=i;
                    jbas=j;
                    countnon=1;
                   
                end 
                  if countnon==1
                          nonx(ibas,jbas)=inf; 
                    break
                  end
                 
            end
             if countnon==1
                         
                    break
             end
        end
       % Construct the equivalent basic cell matrix
       x11=zeros(m+1,n+1);
       x22=zeros(m+1,n+1);
     for j=1:n
         for i=1:m
             
             if x(i,j)>0
                x11(i,j)=x(i,j);
                x22(i,j)=x(i,j);
             end
         end
     end
       %% Construct stepping stone path for searching the improvement index
      for j=1:n
          for i=1:m
              x11(ibas,jbas)=inf;
               x22(ibas,jbas)=inf;
          end
      end
       % Count the number of the basic cell on each row and column
     
    
      for j=1:n
           countcol=0;
          for i=1:m
              if x11(i,j)>0
              countcol=countcol+1;
              end
          end;
          x11(m+1,j)=countcol;
          x22(m+1,j)=countcol;
      end
      for i=1:m
            countrow=0;
          for j=1:n
              if x11(i,j)>0
              countrow=countrow+1;
              end
          end
          x11(i,n+1)=countrow;
          x22(i,n+1)=countrow;
      end
 %% Eliminate the basic variables that has only one on each row 
   iterationloop=0;
  for i=1:m
      iterationloop=iterationloop+1;
    for i=1:m
      if x22(i,n+1)==1 
          ieliminate=i;
         for j=1:n
             if x22(ieliminate,j)<inf &&   x22(ieliminate,j)>0 
                 jeliminate=j;
                x22(ieliminate,jeliminate)=0;% Eliminate the basic variable on row
                x22(ieliminate,n+1)=x22(ieliminate,n+1)-1; % decrease the number of the basic variable on row one unit
                x22(m+1,jeliminate)=x22(m+1,jeliminate)-1; % decrease the number of the basic variable on column one unit
                      
             end
         end
        
      end
    end
  %% Eliminate the basic variables that has only one on each column
  for j=1:n
      if x22(m+1,j)==1
          jeliminate1=j;
          for i=1:m
              if x22(i,jeliminate1)<inf && x22(i,jeliminate1)>0
                  ieliminate1=i;
                  x22(ieliminate1,jeliminate1)=0;% Eliminate the basic variable on row
                  x22(m+1,jeliminate1)=x22(m+1,jeliminate1)-1; % decrease the number of the basic variable on column one unit
                  x22(ieliminate1,n+1)=x22(ieliminate1,n+1)-1;% decrease the number of the basic variable on row one unit
              end
          end
      end
  end
  %% Control the constructing loop path
  for j=1:n
    for i=1:m
        if (x22(i,n+1)==0 || x22(i,n+1)==2) && (x22(m+1,j)==0 || x22(m+1,j)==2) 
           break
        else
                
      
        end
    end
  end 
  end
 %% Make +/-sign on basic variables in the loop path (x2)
     %1. Add - sign on basic variable on row(imax) and on basic variable on
     %column (jmax)
     for j=1:n
           
             if  (x22(ibas,j)~=0 && x22(ibas,j)<inf && x22(ibas,n+1)==2)
              
                 jneg=j;
                 x22(ibas,jneg)=(-1)*x22(ibas,jneg);
                 x22(m+1,jneg)=1;
                 x22(ibas,n+1)=1;
                   for i=1:m
                       if (x22(i,jneg)>0 && x22(m+1,jneg)==1)
                           ineg=i;
                          
                       end
                   end
               
             end
     end
  for p=1:n
     
      for j=1:n
         if (j~=jneg && x22(ineg,j)>0 && x22(ineg,n+1)==2) 
            
                 jneg1=j;
                 x22(ineg,jneg1)=(-1)*x22(ineg,jneg1);
                 x22(ineg,n+1)=1;
                  x22(m+1,jneg1)=1;
       
                 for i=1:m
                   if (x22(i,jneg1)>0 && x22(m+1,jneg1)==1)
                     ineg1=i;
                     ineg=ineg1;
                     jneg=jneg1;
                   end
                 end
         end
      end
      % Control loop
     if  jneg1==jbas
       
         %break
     end   
  end
   %% Compute the improvement index (based on the unit cost of each basic cell)
   
    sumloop=0;
    for i=1:m
        for j=1:n
            if  x22(i,j)~=0
                icost=i;
                jcost=j;
                if x22(icost,jcost)>0
                   sumloop=sumloop+c(icost,jcost);
                elseif x22(icost,jcost)<0
                    sumloop=sumloop+(-1)*c(icost,jcost);
                end
                    
                    
            end
        end
    end
    costloop(ibas,jbas)=sumloop;
  end
 %% Loop controller
 countcontrol=0;
    for j=1:n
        for i=1:m
            if costloop(i,j)>=0
                countcontrol=countcontrol+1;
            end
        end
    end
    if countcontrol==m*n
        return
    end
   
   %% Searching the absolute smallest improvement index
  minindex=0; 
 for j=1:n
       for i=1:m
           if costloop(i,j)<=0
               if costloop(i,j)<=minindex
                   minindex=costloop(i,j);
                   ismall=i;
                   jsmall=j;
               end
           end
       end
 end
 %% Construct a new stepping stone loop using add the new basic variable to change in x matrix
  % Construct the equivalent basic cell matrix
       x33=zeros(m+1,n+1);
       x44=zeros(m+1,n+1);
     for j=1:n
         for i=1:m
             
             if x(i,j)>0
                x33(i,j)=x(i,j);
                x44(i,j)=x(i,j);
             end
         end
     end
      %% Construct stepping stone path for searching the improvement index
      for j=1:n
          for i=1:m
              x33(ismall,jsmall)=inf;
               x44(ismall,jsmall)=inf;
          end
      end
       % Count the number of the basic cell on each row and column
     
    
      for j=1:n
           countcol1=0;
          for i=1:m
              if x33(i,j)>0
              countcol1=countcol1+1;
              end
          end
          x33(m+1,j)=countcol1;
          x44(m+1,j)=countcol1;
      end
      for i=1:m
            countrow1=0;
          for j=1:n
              if x33(i,j)>0
              countrow1=countrow1+1;
              end
          end
          x33(i,n+1)=countrow1;
          x44(i,n+1)=countrow1;
      end             
 % Eliminate the basic variables that has only one on each row 
   iterationloop1=0;
  for i=1:m
      iterationloop1=iterationloop1+1;
    for i=1:m
      if x44(i,n+1)==1 
          ieliminate3=i;
         for j=1:n
             if x44(ieliminate3,j)<inf &&   x44(ieliminate3,j)>0
                 jeliminate3=j;
                x44(ieliminate3,jeliminate3)=0;% Eliminate the basic variable on row
                x44(ieliminate3,n+1)=x44(ieliminate3,n+1)-1; % decrease the number of the basic variable on row one unit
                x44(m+1,jeliminate3)=x44(m+1,jeliminate3)-1; % decrease the number of the basic variable on column one unit
                      
             end
         end
        
      end
    end
 
  %% Eliminate the basic variables that has only one on each column
  for j=1:n
      if x44(m+1,j)==1
          jeliminate4=j;
          for i=1:m
              if x44(i,jeliminate4)<inf && x44(i,jeliminate4)>0
                  ieliminate4=i;
                  x44(ieliminate4,jeliminate4)=0;% Eliminate the basic variable on row
                  x44(m+1,jeliminate4)=x44(m+1,jeliminate4)-1; % decrease the number of the basic variable on column one unit
                  x44(ieliminate4,n+1)=x44(ieliminate4,n+1)-1;% decrease the number of the basic variable on row one unit
              end
          end
      end
  end
   
   
  %% Control the constructing loop path
    for j=1:n
        for i=1:m
        
            if (x44(i,n+1)==0 || x44(i,n+1)==2) && (x44(m+1,j)==0 || x44(m+1,j)==2) 
                break
       
            end       
      
        end
    end
  end 
  
 %% Make +/-sign on basic variables in the loop path (x2)
     %1. Add - sign on basic variable on row(imax) and on basic variable on
     %column (jmax)
     for j=1:n
           
             if  (x44(ismall,j)~=0 && x44(ismall,j)<inf && x44(ismall,n+1)==2)
              
                 jneg=j;
                 x44(ismall,jneg)=(-1)*x44(ismall,jneg);
                 x44(m+1,jneg)=1;
                 x44(ismall,n+1)=1;
                   for i=1:m
                       if (x44(i,jneg)>0 && x44(m+1,jneg)==1)
                           ineg=i;
                          
                       end
                   end
               
             end
     end
  for p=1:n
     
      for j=1:n
         if (j~=jneg && x44(ineg,j)>0 && x44(ineg,n+1)==2) 
            
                 jneg1=j;
                 x44(ineg,jneg1)=(-1)*x44(ineg,jneg1);
                 x44(ineg,n+1)=1;
                  x44(m+1,jneg1)=1;
       
                 for i=1:m
                   if (x44(i,jneg1)>0 && x44(m+1,jneg1)==1)
                     ineg1=i;
                     ineg=ineg1;
                     jneg=jneg1;
                   end
                 end
         end
      end
      % Control loop
     if  jneg1==jsmall
      
        % return
     end   
  end
  % Eliminate  column j that  has the number of basic variables =2
    for j=1:n
        if x44(m+1,j)==2
            for i=1:m
                if x44(i,j)>0
                    x44(i,j)=0;
                end
            end
             x44(m+1,j)=0;
        end
       
    end
    %Eliminate row i that has the number of basic variables =2
      for i=1:m
          if x44(i,n+1)>=2
              for j=1:n
                  if x44(i,j)>0
                      x44(i,j)=0;
                  end
              end
               x44(i,n+1)=0;
          end
         
      end
      %% Searching the absolute smallest path and add this path to (ismall,jsmall) cell
  minpath=inf; 
 for j=1:n
       for i=1:m
           if x44(i,j)<0
               if abs(x44(i,j))<=minpath
                   minpath=abs(x44(i,j));
                   
               end
           end
       end
 end          
  %% Add the new path to x matrix
 for j=1:n
     
     for i=1:m
         
             if x44(i,j)~=0 
                 
                x44(i,j)=abs(x44(i,j)+minpath);
                   if x44(i,j)==0
                       x44(i,j)=inf;
                   end
            
             end
     end 
 end
 % Add a entering (ismall,jsmall)cell to x matrix
    for j=1:n
          for i=1:m
              
               x44(ismall,jsmall)=minpath;
          end
    end
    %% Combine the new path and the non-degeneracy path
 for j=1:n
     for i=1:m
         if x44(i,j)>0
             x(i,j)=x44(i,j);
         
         end
     end
 end
 % Eliminate inf value in x matrix
      for j=1:n
          for i=1:m
              if x(i,j)==inf
               x(i,j)=0;
              end
          end
      end
      %% Check degeneracy
  
     countstepdegen=0;
   
    
     for i=1:m
         for j=1:n
             if x(i,j)>0 && x(i,j)~=inf
                 countstepdegen=countstepdegen+1;
                
             end
         end
     end
     %% Check balance
      % Check demand
      sumdemand=zeros(1,n);
     for j=1:n
         demandsum=0;
         for i=1:m
             if round(x(i,j))>0
                 demandsum=demandsum+round(x(i,j));
             end
         end
         sumdemand(j)=demandsum;
     end
     for j=1:n
         if sumdemand(j)~=round(d(j))
             disp('Unbalanced demand');
             break
         end
     end
     % Check supply
     sumsupply=zeros(m,1);
      for i=1:m
          supplysum=0;
          for j=1:n
              if round(x(i,j))>0
                  supplysum=supplysum+round(x(i,j));
              end
          end
          sumsupply(i)=supplysum;
      end
      for i=1:m
          if sumsupply(i)~=round(s(i))
              disp('Unbalanced supply');
             break
          end
      end
     
    
     if countstepdegen>=reducetant
        
     else 
         % How to correct the degeneracy problem
         %% How to correct degeneracy matrix
     numstepdegen=reducetant-countstepdegen;
     iterationstepDegen=0;
 for A=1:numstepdegen 
     iterationstepDegen=iterationstepDegen+1;
  
  %% Construct the u-v variables
     %% Construct the u-v variables
    udual=zeros(m,1);
    vdual=zeros(1,n);
    for i=1:m
        udual(i)=inf;
    end
    for j=1:n
        vdual(j)=inf;
    end
    udual(1)=0;
   for i=1:1
       for j=1:n
           if x(i,j)>0
               vdual(j)=c(i,j)-udual(i);
           end
       end
   end
   for j=1:1
       for i=1:m
           if x(i,j)>0
               iu=i;
              if udual(iu)<inf
               vdual(j)=c(i,j)-udual(iu);
              else
                  if vdual(j)<inf
                      udual(iu)=c(i,j)-vdual(j);
                  end
              end
           end
       end
   end
 for k=1:m*n  
  for i=1:m
       if udual(i)<inf
          iu=i;
          for j=1:n
            if x(iu,j)>0
             
             vdual(j)=c(iu,j)-udual(iu);
            end
          end
       end
  end
 for j=1:n
     if vdual(j)<inf
         jv=j;
         for i=1:m
             if x(i,jv)>0
                 udual(i)=c(i,jv)-vdual(jv);
             end
         end
     end
 end
 countu=0;
 countv=0;
 for i=1:m
     if udual(i)<inf
      countu=countu+1;   
     end
 end
 for j=1:n
     if vdual(j)<inf
         countv=countv+1;
     end
 end
    if (countu==m & countv==n)
        return
    end
 end 
%% Find the non-basic cells
  unx=zeros(m,n);
  for j=1:n
      for i=1:m
          if x(i,j)==0
              unx(i,j)=udual(i)+vdual(j)-c(i,j);
          end
      end
  end
  %% Search maximum positive of udual+vdual-c(i,j) to reach a new basic variable
  maxunx=0;
  for j=1:n
      for i=1:m
          if unx(i,j)>=maxunx
              maxunx=unx(i,j);
              imax=i;
              jmax=j;
          end
      end
  end
   %% Count the number of  basic variable on each and row
       
     for j=1:n
         sumcol=0;
         for i=1:m
             if x(i,j)>0
                 sumcol=sumcol+1;
             end
         end
             x(m+1,j)=sumcol;
     end
      for i=1:m
         sumrow=0;
         for j=1:n
             if x(i,j)>0
                 sumrow=sumrow+1;
             end
         end
             x(i,n+1)=sumrow;
      end
        %% Construct the equipvalent x matrix
          for j=1:n+1
              for i=1:m+1
                  x1(i,j)=x(i,j);
              end
          end
     %% Eliminate an entering variable for adding a new one
         for j=1:n
              for i=1:m
                  if (x(i,j)==r || x1(i,j)==r)
                   
                      x1(i,j)=0;
                  end
              end
         end
          % Add a new entering variable to x1 matrix
          for j=1:n
              for i=1:m
                 
                  x1(imax,jmax)=r;
              end
          end
        
 % Seaching and adding the entering point for corrective action
      for i=1:m
         if i~=imax
          if x1(i,jmax)>0
              ienter1=i;
               for j=1:n
                  if j~=jmax
                   if x1(ienter1,j)>0
                       jenter1=j;
                   end
                  end
               end
          end
         end
      end
      x1(imax,jenter1)=r;
      x(imax,jenter1)=r;
      % Add demand and supply
      for j=1:n
          d(jenter1)=d(jenter1)+r;
      end
      for i=1:m
          s(imax)=s(imax)+r;
      end
 end
     end
   %The number of basic variable 
   countopt=0;
   for j=1:n
       for i=1:m
           if x(i,j)>0
               countopt=countopt+1;
           end
       end
   end
   % Convert x matrix
   xpath=zeros(m,n);
   for j=1:n
       for i=1:m
           if x(i,j)>0
               xpath(i,j)=round(x(i,j));
           end
       end
   end
 % Total cost
  Zopt=0;
    for j=1:n
        for i=1:m
            if xpath(i,j)>0
                
                Zopt=Zopt+(xpath(i,j)*c(i,j));
            end
        end
    end
 disp('Occupied matrix of SS');
 disp(xpath);
 disp('Total cost');
 disp(Zopt);
 end
   
                
 
toc
 