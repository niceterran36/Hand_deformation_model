

mesh.spheres{1,1}.center = [-74.2300000000000,-18.1500000000000,70.2500000000000];
mesh.spheres{1,1}.radius = 4.3
mesh.spheres{1,1}.bone = 18;

mesh.spheres{1,2}.center = [-69.1500000000000,-17.2800000000000,51.5900000000000];
mesh.spheres{1,2}.radius = 7.45
mesh.spheres{1,2}.bone = 17;

mesh.spheres{1,3}.center = [-62.9600000000000,-14.4000000000000,33.7100000000000];
mesh.spheres{1,3}.radius = 8.40
mesh.spheres{1,3}.bone = 16;

mesh.spheres{1,4}.center = [-52.0600000000000,-14.5100000000000,-0.800000000000000];
mesh.spheres{1,4}.radius = 10.04
mesh.spheres{1,4}.bone = 15;

mesh.spheres{1,5}.center = [-50,-13.1800000000000,97.2000000000000];
mesh.spheres{1,5}.radius = 4.7
mesh.spheres{1,5}.bone = 14;

mesh.spheres{1,6}.center = [-47.0600000000000,-13.3700000000000,77.3200000000000];
mesh.spheres{1,6}.radius = 7.81
mesh.spheres{1,6}.bone = 13;

mesh.spheres{1,7}.center = [-43.3100000000000,-10.7000000000000,51.2300000000000];
mesh.spheres{1,7}.radius = 9.2
mesh.spheres{1,7}.bone = 12;

mesh.spheres{1,8}.center = [-35.4100000000000,-8.17000000000000,6.37000000000000];
mesh.spheres{1,8}.radius = 9.68
mesh.spheres{1,8}.bone = 2;

mesh.spheres{1,9}.center = [-23.1100000000000,-12.7800000000000,110.890000000000];
mesh.spheres{1,9}.radius = 4.76
mesh.spheres{1,9}.bone = 11;

mesh.spheres{1,10}.center = [-22.0600000000000,-11.9100000000000,90.4400000000000];
mesh.spheres{1,10}.radius = 7.95
mesh.spheres{1,10}.bone = 10;

mesh.spheres{1,11}.center = [-20.7800000000000,-6.52000000000000,62.3400000000000];
mesh.spheres{1,11}.radius = 9.11
mesh.spheres{1,11}.bone = 9;

mesh.spheres{1,12}.center = [-19.6800000000000,-0.450000000000000,13.3300000000000];
mesh.spheres{1,12}.radius = 9.69
mesh.spheres{1,12}.bone = 2;

mesh.spheres{1,13}.center = [5.60000000000000,-12.1100000000000,103.850000000000];
mesh.spheres{1,13}.radius = 4.78
mesh.spheres{1,13}.bone = 8;

mesh.spheres{1,14}.center = [5.24000000000000,-12.2000000000000,84.3800000000000];
mesh.spheres{1,14}.radius = 7.99
mesh.spheres{1,14}.bone = 7;

mesh.spheres{1,15}.center = [3.37000000000000,-9.25000000000000,59.5500000000000];
mesh.spheres{1,15}.radius = 9.63
mesh.spheres{1,15}.bone = 6;

mesh.spheres{1,16}.center = [0.670000000000000,3.46000000000000,16.7000000000000];
mesh.spheres{1,16}.radius = 9.45
mesh.spheres{1,16}.bone = 2;

mesh.spheres{1,17}.center = [31.4600000000000,-16.9600000000000,49.2700000000000];
mesh.spheres{1,17}.radius = 4.70
mesh.spheres{1,17}.bone = 5;

mesh.spheres{1,18}.center = [31.6500000000000,-13.7000000000000,23.8300000000000];
mesh.spheres{1,18}.radius = 9.59
mesh.spheres{1,18}.bone = 4;

mesh.spheres{1,19}.center = [29.4300000000000,-15.2000000000000,-9.44000000000000];
mesh.spheres{1,19}.radius = 11.20
mesh.spheres{1,19}.bone = 3;

mesh.spheres{1,20}.center = [12.2400000000000,-12.6000000000000,-40.8300000000000];
mesh.spheres{1,20}.radius = 12.89
mesh.spheres{1,20}.bone = 2;

mesh.spheres{1,21}.center = [11.6500000000000,-7.52000000000000,-1.03000000000000];
mesh.spheres{1,21}.radius = 8.85
mesh.spheres{1,21}.bone = 2;

mesh.spheres{1,22}.center = [-20.4600000000000,-13.3700000000000,-63.2900000000000];
mesh.spheres{1,22}.radius = 0
mesh.spheres{1,22}.bone = 1;

mesh.spheres{1,23}.center = [-41.0700000000000,-8,-37.7700000000000];
mesh.spheres{1,23}.radius = 15.05
mesh.spheres{1,23}.bone = 1;

mesh.spheres{1,24}.center = [-39.8800000000000,-9.31000000000000,-61.8200000000000];
mesh.spheres{1,24}.radius = 10.08
mesh.spheres{1,24}.bone = 1;

mesh.spheres{1,25}.center = [3.36000000000000,-7.52000000000000,-57.6100000000000];
mesh.spheres{1,25}.radius = 10.32
mesh.spheres{1,25}.bone = 1;

mesh.spheres{1,26}.center = [-38.7100000000000,-7.52000000000000,-81.0400000000000];
mesh.spheres{1,26}.radius = 12.31
mesh.spheres{1,26}.bone = 1;

mesh.spheres{1,27}.center = [-19.1500000000000,-7.52000000000000,-111.810000000000];
mesh.spheres{1,27}.radius = 23.66
mesh.spheres{1,27}.bone = 1;

mesh.spheres{1,28}.center = [-47.2300000000000,-7.52000000000000,17.8400000000000];
mesh.spheres{1,28}.radius = 4.13
mesh.spheres{1,28}.bone = 2;

mesh.spheres{1,29}.center = [-29.4000000000000,-7.52000000000000,28.4100000000000];
mesh.spheres{1,29}.radius = 3.63
mesh.spheres{1,29}.bone = 2;

mesh.spheres{1,30}.center = [-9.50000000000000,-7.52000000000000,31.5200000000000];
mesh.spheres{1,30}.radius = 3.77
mesh.spheres{1,30}.bone = 2;



